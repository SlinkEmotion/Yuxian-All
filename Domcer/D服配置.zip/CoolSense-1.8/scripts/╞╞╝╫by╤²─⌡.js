﻿var scriptName = "HytKa";
var scriptAuthor = "Minger";
var scriptVersion = 1.0;

var File = Java.type("java.io.File");
var FileReader = Java.type("java.io.FileReader");
var BufferedReader = Java.type("java.io.BufferedReader");
var FileWriter = Java.type("java.io.FileWriter");
var BufferedWriter = Java.type("java.io.BufferedWriter");
var Timer = Java.type("java.util.Timer");

var config = {
    hYT: true,
    spamDelay: 900,
}

var chatPrefix = "§dMinger HytKa";

function log(message, isError) {
    if (isError) {
        chat.print(chatPrefix + " §c§l" + message);
    } else {
        chat.print(chatPrefix + " §f§l" + message);
    }
}


function randomString(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
}

function setInterval(func, milliseconds) {
    var timer = new Timer("setInterval", true);

    timer.schedule(function () {
        func();
    }, milliseconds, milliseconds);

    return timer;
}

function clearInterval(timer) {
    timer.cancel();
}

function setTimeout(func, milliseconds) {
    var timer = new Timer("setTimeout", true);
    timer.schedule(function () {
        func();
    }, milliseconds);

    return timer;
}

function FileSpammerModule() {
    var spamInterval;

    this.getName = function () {
        return "HytKa";
    }

    this.getDescription = function () {
        return "JPEP！我是不会空刀的！";
    };

    this.getCategory = function () {
        return "Fun";
    }

    this.onEnable = function () {

        var spamFile = ["KillAura MaxCPS 17","KillAura MinCPS 15","KillAura Hurttime 10","KillAura Range 4.6"]
		var spamIndex = 0;

        spamInterval = setInterval(function () {
            if (config.hYT) {
				if(config.hYT){
					commandManager.executeCommand("." + spamFile[spamIndex]);
				}else {
					log("你没有开启HYT模式,请输入.HytKa hyt");
				}
            } else {
				if(config.hYT){
					commandManager.executeCommand("." + spamFile[spamIndex]);
				}else {
					log("你没有开启HYT模式,请输入.HytKa hyt");
				}
                
            }

            if (spamIndex < spamFile.length - 1) {
                spamIndex++;
            } else {
                spamIndex = 0;
            }
        }, config.spamDelay);
    }

    this.onDisable = function () {
        clearInterval(spamInterval);
    }
}

function FileSpammerCommand() {
    this.getName = function () {
        return "HytKa";
    }

    this.getAliases = function () {
        return ["ka"];
    }

    this.execute = function (args) {
        if (args.length < 2) {
            log("指令错误: .HytKa <hyt/delay>", true);
            return;
        }

        switch (args[1].toLowerCase()) {
            case "hyt":
                config.hYT = !config.hYT;
                log("jpepHytKa已经开启！我是不会空刀的！ " + config.hYT, false);
                

                break;

            case "delay":
                if (args.length < 3) {
                    log("指令错误: .HytKa delay <ms>", true);
                    return;
                }

                var input = parseInt(args[2]);

                if (input < 0) {
                    log("请输入一个比0大的数", true);
                    return;
                }

                config.spamDelay = input;
                log("速度设置为: " + input, false);
                

                break;

            default:
                log("指令错误: .HytKa <hyt/delay>", true);
        }
    }
}

var fileSpammerModule = new FileSpammerModule();
var fileSpammerCommand = new FileSpammerCommand();

var fileSpammerModuleClient;
var fileSpammerCommandClient;

function onEnable() {

    fileSpammerModuleClient = moduleManager.registerModule(fileSpammerModule);
    fileSpammerCommandClient = commandManager.registerCommand(fileSpammerCommand);
}

function onDisable() {
    moduleManager.unregisterModule(fileSpammerModuleClient);
    commandManager.unregisterCommand(fileSpammerCommandClient);
}