var scriptName = "HytBlinkFlyPlus";
var scriptVersion = 2.0;
var scriptAuthor = "fu917"
var BlinkModule = moduleManager.getModule("Blink");
var HytZoomFly = new HytZoomFly();
var client;


var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')

function HytZoomFly() {
	var Mode = value.createList("Mode", ["NoDamage"], "NoDamage");
	var Speed = value.createFloat("Speed", 0, 0, 5);
	
    this.getName = function() {
        return "HytBlinkFlyPlus";
    };
    this.getDescription = function() {
        return "HytBlinkFlyPlus";
    };
    this.getCategory = function() {
        return "Fun";
    };
	this.getTag = function() {
		return "NoDamage";
	};
    this.onEnable = function() {
		BlinkModule.setState(true);
    };
    this.onDisable = function() {
		BlinkModule.setState(false);
        mc.timer.timerSpeed = 1
        mc.thePlayer.noClip = false
    }
    this.onUpdate = function() {
					    switch(Mode.get()) {
					    case "NoDamage":	
		            
				mc.thePlayer.capabilities.isFlying = false;
                if(mc.thePlayer.onGround) 
                mc.thePlayer.jump();
				else{
				mc.thePlayer.motionY = 0;
                mc.thePlayer.motionX = 0;
                mc.thePlayer.motionZ = 0;
                if(mc.gameSettings.keyBindJump.isKeyDown())
                    mc.thePlayer.motionY += Speed.get();
                if(mc.gameSettings.keyBindSneak.isKeyDown())
                    mc.thePlayer.motionY -= Speed.get();
                MovementUtils.strafe(Speed.get());
				break;
				}
						}
    }
		this.addValues = function(values) {
		values.add(Mode);
		values.add(Speed);
    };
}

function onLoad() {}

function onEnable() {
   HytZoomFlyClient = moduleManager.registerModule(HytZoomFly)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}