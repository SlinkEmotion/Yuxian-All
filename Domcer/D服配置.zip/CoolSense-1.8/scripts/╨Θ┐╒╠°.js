var scriptName = "HytJump";
var scriptVersion = 1.1;
var scriptAuthor = "神帝"
var BlinkModule = moduleManager.getModule("Blink");
var HytHighJump = new HytHighJump();
var client;

function HytHighJump() {
	var MotionY = value.createFloat("CustomMotionY", 1, 5, 8);
	
    this.getName = function() {
        return "HytJump";
    };
    this.getDescription = function() {
        return "HytJump";
    };
    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
		BlinkModule.setState(true);
		                               mc.thePlayer.motionY = MotionY.get();
    };
    this.onDisable = function() {
		BlinkModule.setState(false);
    }
		this.addValues = function(values) {
		values.add(MotionY);
    }
}

function onLoad() {}

function onEnable() {
   HytHighJumpClient = moduleManager.registerModule(HytHighJump)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}