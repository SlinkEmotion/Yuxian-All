﻿var scriptName = "Title"
var scriptVersion = 1.0
var scriptAuthor = "SharkRock"

var Title = new Title()
var client

function Title() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
	
	this.getName = function() {
        return "Electrolux Title"
    }

    this.getDescription = function() {
        return "Sharkrock"
    }

    this.getCategory = function() {
        return "Fun"
    }

    this.onUpdate = function() {
		 HM += 1
		 if (HM ==20){
		   S = S + 1
		   HM = 0
		   
		  }
		 if (S ==60){
		   M = M +1
		   S = 0
		  }
		  if (M==60){
		   H = H+1
		   M = 0
		  }
		Display.setTitle(' 余弦Config 丨 她会回来的，我相信她，所有的谎言终将被识破，她不会回来的，放手吧 该醒醒了 丨 ' +  H  +'  时  '  +M +'  分  '+S+'  秒  ')
	}
}

var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Title)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}