var script = registerScript({
    name: "AAC4Velocity",
    version: "2.0",
    authors: ["AquaVit"]
});

var SPacketUpdateHealth = Java.type('net.minecraft.network.play.server.SPacketUpdateHealth')
var SPacketEntityVelocity = Java.type('net.minecraft.network.play.server.SPacketEntityVelocity')
var SPacketExplosion = Java.type('net.minecraft.network.play.server.SPacketExplosion')
var MSTimer = Java.type("net.ccbluex.liquidbounce.utils.timer.MSTimer")
var timer = new MSTimer()
var hurt = false

script.registerModule({
    name: "AAC4Velocity",
    description: ":/",
    category: "Combat",
    tag: ">3",
    settings: {
		mode: Setting.list({
            name: "Mode",
            values: ["AAC4"],
            default: "AAC4"
        })
    }
}, function (module) {
	module.on("update", function () {
		if (module.settings.mode.get() == "AAC4"){
			if (!mc.thePlayer.onGround) {
				if (mc.thePlayer.hurtTime != 0){
                if (hurt) {
					mc.gameSettings.keyBindForward.isKeyDown() == true
                    mc.thePlayer.speedInAir = 0.02
                    mc.thePlayer.motionX *= 0.6
                    mc.thePlayer.motionZ *= 0.6
                }
			}
			} else{
			if (timer.hasTimePassed(80)) {
                hurt = false
                mc.thePlayer.speedInAir = 0.02
				}
			}
		}
	});
    module.on("packet", function (event) {
        var packet = event.getPacket()
		if (packet instanceof SPacketEntityVelocity) {
			if (mc.thePlayer == null){
				return
			}
            timer.reset()
			hurt = true
		}
		if (packet instanceof SPacketUpdateHealth) {
            event.cancelEvent()
        }

        if (packet instanceof SPacketExplosion) {
            event.cancelEvent()
        }
    });
});