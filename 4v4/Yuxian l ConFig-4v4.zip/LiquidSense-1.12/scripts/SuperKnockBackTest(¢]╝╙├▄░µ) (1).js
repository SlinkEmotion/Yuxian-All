var scriptName = "SuperKnockBack";
var scriptVersion = 1.1;
var scriptAuthor = "菜鸟秉锜++";

var C0APacketAnimation = Java.type('net.minecraft.network.play.client.C0APacketAnimation');
var C09PacketHeldItemChange = Java.type('net.minecraft.network.play.client.C09PacketHeldItemChange');
var C08PacketPlayerBlockPlacement = Java.type('net.minecraft.network.play.client.C08PacketPlayerBlockPlacement');
var C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging');
var C06PacketPlayerPosLook = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook');
var C04PacketPlayerPosition = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition');
var C05PacketPlayerLook = Java.type('net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook');
var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var C02PacketUseEntity = Java.type('net.minecraft.network.play.client.C02PacketUseEntity');
var C0BPacketEntityAction = Java.type('net.minecraft.network.play.client.C0BPacketEntityAction');
var S08PacketPlayerPosLook = Java.type('net.minecraft.network.play.server.S08PacketPlayerPosLook');
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat');

var C0CPacketInput = Java.type('net.minecraft.network.play.client.C0CPacketInput');
var C18PacketSpectate = Java.type('net.minecraft.network.play.client.C18PacketSpectate');
var C13PacketPlayerAbilities = Java.type('net.minecraft.network.play.client.C13PacketPlayerAbilities');
var C0FPacketConfirmTransaction = Java.type('net.minecraft.network.play.client.C0FPacketConfirmTransaction');
var C00PacketKeepAlive = Java.type('net.minecraft.network.play.client.C00PacketKeepAlive');

var EntityLivingBase = Java.type("net.minecraft.entity.EntityLivingBase");

var SuperKnockBackModule = new SuperKnockBackModule();
var Client;

var KillAuraModule = moduleManager.getModule("KillAura");
var VelocityModule = moduleManager.getModule("Velocity");

function SuperKnockBackModule() {
    var Mode = value.createList("Mode", ["Normal", "MCYC"], "Normal");

    this.getName = function() {
        return "SuperKnockBack2";
    };

    this.getDescription = function() {
        return "lol ";
    };

    this.getTag = function() {
        return Mode.get();
    };

    this.getCategory = function() {
        return "Misc";
    };

    this.onAttack = function(event) {
        switch (Mode.get()) {
            case "Normal":
                target = event.getTargetEntity();
                mc.thePlayer.serverSprintState = true;
                mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                break;
            case "MCYC":
                var entity = event.getTargetEntity();
                if (mc.thePlayer.isSprinting())
                    mc.thePlayer.setSprinting(false);
                mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                mc.thePlayer.setSprinting(true);
                mc.thePlayer.serverSprintState = true;
                break;
        }
    }

    this.addValues = function(values) {
        values.add(Mode);
    }
}

function onLoad() {}

function onEnable() {
    Client = moduleManager.registerModule(SuperKnockBackModule);
}

function onDisable() {
    moduleManager.unregisterModule(Client);
}