﻿var scriptName = "IQ";
var scriptVersion = 1.0;
var scriptAuthor = "IQBoost"
var IQ = new IQ();
var client;

function IQ() {
	var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils')
	var ArrayList = Java.type('java.util.ArrayList');
	var LinkedList = Java.type('java.util.LinkedList');
    this.getName = function() {
        return "IQ";
    };
    
	this.getDescription = function() {
        return "Help you add your IQ.";
    };
    
	this.getCategory = function() {
        return "Misc";
	};
	
	this.getTag = function() {
		return "114514";
	};
}
function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(IQ);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}