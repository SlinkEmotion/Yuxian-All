
//部分内容由rise添加，此js为公开js
var scriptName = "Auto";//
var scriptVersion = 2.0;
var scriptAuthor = "No";

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat')
var Debug = new Debug();
var client;

function Debug() {
var xl = value.createFloat("Health", 6, 0, 20);
var text = value.createText("1Text", "/hub");

var dis = value.createBoolean("AutoDisable Killaura autoblock+", true);
var e = false;

    this.getName = function() {
        return "AutoLobby";
    };

    this.getDescription = function() {
        return "No";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {

    }

    this.onUpdate = function() {
if (mc.thePlayer.getHealth() < xl.get() & e == false){
	mc.thePlayer.sendChatMessage(text.get());
if (dis.get()){
moduleManager.getModule("Killaura").setState(false)
moduleManager.getModule("autoblock+").setState(false)

}

	e = true;
}
if (mc.thePlayer.getHealth() >= xl.get()){
	e = false;
}


	}
    this.onDisable = function () {	
	}
	this.addValues = function(values) { 
		values.add(xl);
		values.add(text);
		values.add(dis);

	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}