var scriptName = "AB";
var scriptVersion = 1.0;
var scriptAuthor = "LaoTong";

var BlockPos = Java.type('net.minecraft.util.BlockPos');
var C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging');
var C08 = Java.type('net.minecraft.network.play.client.C08PacketPlayerBlockPlacement');
var EnumFacing = Java.type('net.minecraft.util.EnumFacing');
var Interactpacket = Java.type('net.minecraft.network.play.client.C02PacketUseEntity');
var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');
var KillAuraClass = Java.type("net.ccbluex.liquidbounce.LiquidBounce").moduleManager.getModule(Java.type("net.ccbluex.liquidbounce.features.module.modules.combat.KillAura").class);
var AB = new AB();
var client;

function AB() {

    var BlockMode = value.createList("AutoBlockMode", ["Hypixel","Vanilla"], "Hypixel");

    this.getName = function() {
        return "AutoBlock+";
    };

    this.getTag = function() {
        return "" + BlockMode.get();
    };

    this.getDescription = function() {
        return "AB";
    };

    this.getCategory = function() {
        return "Combat";
    };

    this.addValues = function(values) {
        values.add(BlockMode);
    }

    this.onAttack = function (event) {
        if (event.getTargetEntity() instanceof EntityPlayer) {
            entity = event.getTargetEntity();
        }
        switch (BlockMode.get()) {
            case "Hypixel":
                KillAuraClass.blockingStatus = true
                block();
                break;
			case "Vanilla":
                KillAuraClass.blockingStatus = true
                block();
                break;
        }
    };
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(AB);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}