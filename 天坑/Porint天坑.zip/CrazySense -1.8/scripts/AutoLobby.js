

var scriptName = "111";//Js名字
var scriptVersion = 1.0;//Js版本
var scriptAuthor = "JS";//Js作者

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat')
var Debug = new Debug();
var client;

function Debug() {
var xl = value.createFloat("Health", 5, 0, 20);
var text = value.createText("Text", "/hub");
var dis = value.createBoolean("AutoDisable Speed Killaura Velocity CookieVelocity", true);
var e = false;

    this.getName = function() {
        return "AutoLobby1";
    };

    this.getTag = function () {
        return "Porint";
    };

    this.getDescription = function() {
        return "457604989";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {

    }

    this.onUpdate = function() {
if (mc.thePlayer.getHealth() < xl.get() & e == false){
	mc.thePlayer.sendChatMessage(text.get());
if (dis.get()){
moduleManager.getModule("Speed").setState(false)
moduleManager.getModule("Killaura").setState(false)
moduleManager.getModule("Velocity").setState(false)
moduleManager.getModule("CookieVelocity").setState(false)

}

	e = true;
}
if (mc.thePlayer.getHealth() >= xl.get()){
	e = false;
}


	}
    this.onDisable = function () {	
	}
	this.addValues = function(values) { 
		values.add(xl);
		values.add(text);
		values.add(dis);

	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}