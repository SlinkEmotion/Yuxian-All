var scriptName = "BlinkCrit"; 
var scriptVersion = 1.0; 
var scriptAuthor = "LaoTong.";

var BlinkCrit = new BlinkCrit(); 
var BlinkCritClient;
var Blink = moduleManager.getModule("Blink");


function BlinkCrit() {
	var Mode = value.createList("Mode", ["Hyt","LowFix","LowHop","LowFix2"], "Hyt");

    this.getName = function() {
        return "BlinkCrit";
    };

    this.getDescription = function() {
        return "BlinkCrit In HuaYuTing.";
    };

    this.getCategory = function() {
        return "Fun";
    };
	this.getTag = function() {
        return Mode.get(); 
    };
    this.onAttack = function (event) {
		target = event.getTargetEntity();
		if(mc.thePlayer.onGround) {
		switch(Mode.get()) {
		case "Hyt":
		mc.thePlayer.motionY = 0.3;
		break;
		case "LowHop":
		mc.thePlayer.motionY = 0.25;
		break;
		case "LowFix":
		mc.thePlayer.motionY = 0.3;
		mc.thePlayer.timerSpeed = 0.8848;
		break;
		case "LowFix2":
		Blink.setState(true)
		mc.thePlayer.motionY = 0.3;
		mc.thePlayer.timerSpeed = 0.8848;
		Blink.setState(false)
		break;
		}
		}
	}
	this.onDisable = function() {
	}
	this.onPacket = function(event) {
		if(Mode.get() == "NoGround") {
		var packet = event.getPacket();
		if(packet instanceof C03PacketPlayer) {
			packet.onGround = false;
		}
		}
	}
	this.addValues = function(values) {
		values.add(Mode);
		
    }
}

function onLoad() {
};

function onEnable() {
    BlinkCritClient = moduleManager.registerModule(BlinkCrit);
};

function onDisable() {
    moduleManager.unregisterModule(BlinkCritClient);
};