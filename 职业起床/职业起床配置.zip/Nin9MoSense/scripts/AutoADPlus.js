var scriptName = "AutoADPlus";
var scriptVersion = 2.0;
var scriptAuthor = "liaoyilin&herobrine";

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,QQ,a;
	var random = new Random();
    this.getName = function() {	
        return "AutoADPlus";
    };

    this.getDescription = function() {
        return "JS";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
		HM = 0;
		
    }
    this.onUpdate = function() {
    HM += 1;
    if (HM == 130){
        HM = 0;
        mc.thePlayer.sendChatMessage("@轩野内部配置稳定2h购买+Q①〇伞似⑦伍⑧久衣久暑假优惠只需10r！！！心动不如行动快点加我吧");
    }
}
    this.onDisable = function () {	
	}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}