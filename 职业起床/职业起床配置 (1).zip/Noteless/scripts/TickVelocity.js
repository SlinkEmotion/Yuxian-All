var scriptName = "Tick+Velocity";
var scriptVersion = 1.0;
var scriptAuthor = "LaoTong"; 

var HytVelocity = new HytVelocity();
var Client;

function HytVelocity() {
    this.getName = function() {
        return "HytVelocity";
    };

    this.getDescription = function() {
        return "TickFix";
    };

    this.getTag = function() {
        return "TickFix";
    };
   
    this.getCategory = function() {
        return "Misc";
    };
    
    this.onUpdate = function() { 
        if(mc.thePlayer.hurtTime > 0 && mc.thePlayer.hurtTime <= 6) {
           mc.thePlayer.motionX = 0.0;
           mc.thePlayer.motionZ = 0.0;
		   mc.thePlayer.jumpMovementFactor = -0.001;
             
        }
    }
}

function onLoad() {
     
};

function onEnable() {
    exampleModuleClient = moduleManager.registerModule(HytVelocity);
};

function onDisable() {
    moduleManager.unregisterModule(Client);
};