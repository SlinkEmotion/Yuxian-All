﻿var script = registerScript({
    name: "NoSlowDown",
    version: "1.3",
    authors: ["Co丶Dynamic"]//Fixed edd too by laotong
});
var C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging');
var C06PacketPlayerPosLook = Java.type("net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook");
var BlockPos = Java.type("net.minecraft.util.BlockPos")
var C08PacketPlayerBlockPlacement = Java.type("net.minecraft.network.play.client.C08PacketPlayerBlockPlacement")
var KillAuraClass = Java.type("net.ccbluex.liquidbounce.LiquidBounce").moduleManager.getModule(Java.type("net.ccbluex.liquidbounce.features.module.modules.combat.KillAura").class);
function isBlocking() {
	if (mc.thePlayer.isUsingItem()) return true;
    return mc.thePlayer && (mc.thePlayer.isBlocking() || KillAuraClass.blockingStatus)
}
script.registerModule({
    name: "NoooooSlow",
    description: "In Hypixel",
    category: "Fun",
    settings: {
    }
}, function (module) {
		x = mc.thePlayer.motionX
	z = mc.thePlayer.motionZ
	y = mc.thePlayer.motionY
    module.on("slowDown", function (event) {
        event.forward = 1.0
        event.strafe = 1.0
    });
    module.on("motion", function (event) { try {
        module.tag = "NewVanilla";
        var heldItem = mc.thePlayer.getHeldItem()
        if (isBlocking() && heldItem) {
            switch (event.getEventState().getStateName()) {
                case "PRE":
                    break;
                case "POST":
                    mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging.C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem() , ground))
                    break;
            }
        }
	}catch(err){
	};
    });
});